import traceback
import requests
from urllib.parse import urlencode as _urlencode

from .module_parts import BaseModule, ListModule, TreeModule, SingletonModule, Method
from ._utils import join_url
from .requests import WebRequest
from ._utils import is_pyodide_context, flatten_dict
from .dialog import Dialog

if is_pyodide_context():
    from js import FormData
    from pyodide.ffi import JsProxy


class Modules:
    """
    Used to retrieve modules from the viur-backend.
    """

    def __init__(self, base_url: str, username: str, password: str, login_skey: str = None):
        self._base_url = base_url
        self._username = username
        self._password = password
        self._login_skey = login_skey
        self._session = None
        self._cookies = None
        self._modules = None

    def is_logged_in(self):
        return self._session is not None and self._cookies is not None

    if is_pyodide_context():

        async def init(self):
            resp = await self._viur_request("GET", "/config", renderer="vi")
            try:
                self._modules = resp["modules"]
            except KeyError:
                # TODO throw error?
                self._modules = []
    else:
        async def init(self):
            self._session = requests.sessions.Session()
            skey = self._session.get(self._base_url + "/json/skey")

            kwargs = {
                "data": {
                    "skey": skey.json(),
                    "name": self._username,
                    "password": self._password
                }
            }
            if self._login_skey:
                kwargs["headers"] = {"X-Scriptor": self._login_skey}

            response = self._session.post(self._base_url + "/vi/user/auth_userpassword/login?@vi-admin=true", **kwargs)

            Dialog.print(f"""LOGIN RESPONSE:\n{response.content = }""")

            if response.status_code == 200 and response.json() != "FAILURE":
                Dialog.print("LOGIN SUCCESS")
                self._cookies = requests.sessions.cookiejar_from_dict(self._session.cookies.get_dict())
            else:
                Dialog.print("LOGIN FAILED")

            resp = await self._viur_request("GET", "/config", renderer="vi")
            try:
                self._modules = resp["modules"]
            except KeyError:
                self._modules = []

    async def logout(self):
        await self._viur_request("SECURE_POST", "/json/user/logout")
        self._session = None
        self._cookies = None
        self._modules = None
        Dialog.print("logout success")

    async def _viur_request(self, method: str, url: str, params=None, renderer: str = None):
        method = method.upper()
        assert method in ('GET', 'PUT', 'POST', 'DELETE', 'PATCH', 'SECURE_POST'), "method not supported"
        if method == "SECURE_POST":
            skey = await self._viur_request("GET", "/skey", renderer=renderer)
            try:
                params["skey"] = skey
            except TypeError:
                params = {"skey": skey}
            method = "POST"

        if not url.startswith("/"):
            url = "/" + url

        prefix = f"""/{renderer}""" if renderer else "/json"

        url = prefix + url
        if url and not any(url.startswith(prefix) for prefix in ('http://', 'https://', '//')):
            url = join_url((self._base_url, url))

        data = None

        if params:
            if method == "GET":
                url += "?" + _urlencode(params)
            else:
                data = params

        kwargs = self._viur_request_kwargs_collector(data=(data if method == "POST" else None))

        response = await WebRequest.request(method, url, **kwargs)
        if response.get_status_code() < 200 or response.get_status_code() >= 300:
            raise RuntimeError(
                f"""Request of type "{method}" for URL "{url}" returned with status-code {response.get_status_code()}""")
        return response.as_object_from_json()

    if is_pyodide_context():
        def _viur_request_kwargs_collector(self, data=None):
            kwargs = {
                "headers": {"Accept": "application/json, text/plain, */*"},
                "credentials": "include"
            }
            if data:
                if isinstance(data, dict):
                    fd = FormData.new()
                    for k, v in flatten_dict(data):
                        fd.append(k, v)
                    kwargs["body"] = fd
                elif isinstance(data, JsProxy) and repr(data) == "[object FormData]":
                    kwargs["body"] = data
                else:
                    raise ValueError(f"data must be a dict or FormData, but is {type(data)}")
            return kwargs
    else:
        def _viur_request_kwargs_collector(self, data=None):
            kwargs = {
                "headers": {"Accept": "application/json, text/plain, */*"}
            }
            if self._cookies:
                kwargs["cookies"] = self._cookies
            else:
                raise RuntimeError("You need to log in.")
            if data:
                kwargs["data"] = data
            return kwargs

    def __repr__(self):
        if self._modules is None:
            module_list = "uninitialized"
        else:
            module_list = [i for i in self._modules if not i.startswith('_')]
        return f"""<{self.__class__.__name__}, modules: {module_list}>"""

    async def get_module(self, module_name: str):
        """
        gets a modules from the viur-backend

        :param module_name: the name of the module
        :return: the module
        """
        if module_name in ("__wrapped__",
                           "_repr_mimebundle_",
                           "_ipython_canary_method_should_not_exist_",
                           "_ipython_display_"):  # fixes iPython autocomplete and iPython-"repr"
            return None
        modules_resolver = {
            "tree": TreeModule,
            "hierarchy": TreeModule,
            "list": ListModule,
            "singleton": SingletonModule
        }

        details = self._modules.get(module_name,
                                    None)  # await self._viur_request("GET", module_name, None, renderer='vi')
        if details:
            module_type = None
            for key, value in modules_resolver.items():
                try:
                    _handler = details["handler"]
                except KeyError:
                    try:
                        _handler = details["action"]
                    except KeyError:
                        raise KeyError("details has no action and no handler")
                if _handler.startswith(key):
                    module_type = value
                    break

            # If the module has a registered type
            if module_type:

                # Ensure one instance of the module
                if "type" not in details:
                    details["type"] = module_type

                if "instance" not in details:
                    details["instance"] = details["type"](module_name, parent=self)
                    module: BaseModule = details["instance"]
                    try:
                        if "functions" in details or "methods" in details:
                            exposed_list = details.get("functions", details.get("methods"))
                            for exposed_name, data in exposed_list.items():
                                method = Method(
                                    exposed_name, module, data["accepts"],
                                    skey=data.get("skey", None),
                                    parent=True
                                )
                                details["instance"].register_route(exposed_name, method)
                    except:
                        Dialog.print(traceback.format_exc())

                return details["instance"]
        raise AttributeError(f"""'{__name__}' module hast no attribute '{module_name}'""")
