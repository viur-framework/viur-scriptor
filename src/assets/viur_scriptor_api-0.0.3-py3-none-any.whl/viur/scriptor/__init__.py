from .requests import WebRequest, WebResponse
from .dialog import Dialog  # alert, select, confirm, text, number, date, show_diff, table
from .file import File
from .logger import logger
from .module import Modules
from ._utils import is_pyodide_context, is_pyodide_in_browser, gather_async_iterator
import os
from requests.exceptions import ConnectionError
from .directory_handler import DirectoryHandler

modules = None

if is_pyodide_context():
    import config


    async def _init_modules():  # TODO init hier fertig machen und aufraufen, aus js-seite entfernen
        global modules
        modules = Modules(config.BASE_URL, None, None)
        await modules.init()
        return True
else:
    async def _init_modules(base_url=None, username=None, password=None):
        global modules
        assert not modules, "already initialized"
        try:
            modules = Modules(base_url=base_url or os.environ.get('SCRIPTOR_TARGET', None),
                              username=username or os.environ.get('SCRIPTOR_USER', None),
                              password=password or os.environ.get('SCRIPTOR_PASSWORD', None))
            await modules.init()
            return True
        except ConnectionError:
            print('Connection failed.')
            modules = None
            return False

__all__ = [
    # 'help',
    'is_pyodide_context',
    'is_pyodide_in_browser',
    'WebRequest',
    'WebResponse',
    'DirectoryHandler',
    # 'alert',
    # 'show_diff',
    # 'table',
    # 'select',
    # 'confirm',
    # 'text',
    # 'number',
    # 'date',
    'Dialog',
    'File',
    'logger',
    # 'Modules',
    'modules',
    'ConnectionError',
    'gather_async_iterator'
]

if is_pyodide_context():
    import traceback
    from pyodide.ffi import JsException
    import pydoc

    print = Dialog.print


    def help(thing):
        print(pydoc.render_doc(thing, renderer=pydoc._PlainTextDoc()))


    __all__.extend(['print', 'traceback', 'JsException', 'help'])
